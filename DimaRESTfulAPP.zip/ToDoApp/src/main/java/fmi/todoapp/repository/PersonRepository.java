package fmi.todoapp.repository;

import org.springframework.data.repository.CrudRepository;
import fmi.todoapp.model.Person;

public interface PersonRepository extends CrudRepository<Person, Long> {
}
