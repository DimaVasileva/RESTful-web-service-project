package fmi.todoapp.repository;

import org.springframework.data.repository.CrudRepository;
import fmi.todoapp.model.ToDo;

public interface ToDoRepository extends CrudRepository<ToDo, Long> {
}
