package fmi.todoapp.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.*;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "task_lists")
@NoArgsConstructor
@Getter
@Setter
public class ToDoList {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "task_list_id", nullable = false)
	private Long id;

	@CreationTimestamp
	@Column(name = "date_created")
	private LocalDateTime created;

	@UpdateTimestamp
	@Column(name = "date_updated")
	private LocalDateTime updated;

	@Column(name = "task_list_category", nullable = false)
	private String category;

	@Column(name = "is_active", nullable = false)
	private Boolean active;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "owner")
	private List<ToDo> todos = new ArrayList<>();

	@ManyToOne
	private Person owner;

	// getters and setters
}
