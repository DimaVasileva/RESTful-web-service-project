package fmi.todoapp.model;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.*;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tasks")
@NoArgsConstructor
@Getter
@Setter
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_id", nullable = false)
    private Long id;

    @CreationTimestamp
    @Column(name = "date_created")
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "date_updated")
    private LocalDateTime updated;

    @Column(name = "task_title", nullable = false)
    private String title;

    @Column(name = "task_description")
    private String description;

    @Column(name = "task_deadline")
    private LocalDateTime deadline;

    @Column(name = "is_active", nullable = false)
    private Boolean active;


}
