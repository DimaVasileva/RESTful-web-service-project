package fmi.todoapp.service;

import org.springframework.stereotype.Service;

import fmi.todoapp.model.ToDo;
import fmi.todoapp.repository.ToDoRepository;

@Service
public class ToDoService {

    private final ToDoRepository toDoRepository;

    public ToDoService(ToDoRepository toDoRepository) {
        this.toDoRepository = toDoRepository;
    }

    public ToDo findById(Long id) {
        return toDoRepository.findById(id).orElse(null);
    }

    public Iterable<ToDo> findAll() {
        return toDoRepository.findAll();
    }

    public ToDo save(ToDo toDo) {
        return toDoRepository.save(toDo);
    }

    public void deleteById(Long id) {
        toDoRepository.deleteById(id);
    }
}
