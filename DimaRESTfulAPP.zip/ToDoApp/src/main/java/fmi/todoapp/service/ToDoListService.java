package fmi.todoapp.service;

import org.springframework.stereotype.Service;

import fmi.todoapp.model.ToDoList;
import fmi.todoapp.repository.ToDoListRepository;

@Service
public class ToDoListService {

    private final ToDoListRepository toDoListRepository;

    public ToDoListService(ToDoListRepository toDoListRepository) {
        this.toDoListRepository = toDoListRepository;
    }

    public ToDoList findById(Long id) {
        return toDoListRepository.findById(id).orElse(null);
    }

    public Iterable<ToDoList> findAll() {
        return toDoListRepository.findAll();
    }

    public ToDoList save(ToDoList toDoList) {
        return toDoListRepository.save(toDoList);
    }

    public void deleteById(Long id) {
        toDoListRepository.deleteById(id);
    }
}
