package fmi.todoapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import fmi.todoapp.model.Person;
import fmi.todoapp.repository.PersonRepository;

@SpringBootApplication
public class ToDoAppApplication {

	@Autowired
	private PersonRepository personRepository;

	public static void main(String[] args) {
		SpringApplication.run(ToDoAppApplication.class, args);
	}
}
